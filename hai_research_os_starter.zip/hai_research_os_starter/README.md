# HAI Research OS — starter

**Scope:** A safe, small, automatically scheduled literature-metadata scout. This starter does **not** synthesize full-text evidence with an LLM, run human experiments, claim research novelty or continuously autonomously decide research priorities. Those require added tools and researcher review.

## What it produces
- `reports/YYYY-MM-DD.md`: daily OpenAlex search results with DOI/OpenAlex links
- `data/seen.json`: deduplication key list
- GitHub Actions schedule: every day at 06:17 in `Asia/Tokyo` (best effort, not strict SLA)

## First setup
1. Create a **private** GitHub repository, for example `hai-research-os`.
2. Upload the contents of this folder into the repository root, including `.github/workflows/daily-literature.yml`.
3. Sign up for a free OpenAlex account at https://openalex.org/ and obtain the API key from Settings. OpenAlex offers a limited free daily API allowance; consult their current terms.
4. In GitHub repository **Settings → Secrets and variables → Actions**, create repository secret `OPENALEX_API_KEY` with your key. Never commit keys.
5. Open **Actions → Daily literature discovery → Run workflow** to test manually.
6. Check the generated `reports/` file and the Actions logs. Scheduled runs use best-effort cron and can be delayed or dropped.

## Run locally (Python 3.10+; no additional packages)

```bash
python -m unittest discover -s tests -v
OPENALEX_API_KEY=your_key python scripts/daily_scout.py
```

Leave out `OPENALEX_API_KEY` for very small experiments if permitted by OpenAlex's current anonymous budget.

## Adjust your research scope
Edit `config/research.json`: change search phrases, start date, or maximum results per query. The initial run may find several papers; after that, the `seen.json` dedup list prevents them from recurring.

## Next three extensions
1. **Evidence extraction:** Elicit Routine using `prompts/elicit_routine.txt`; review DOI links and full texts before moving claims to your evidence matrix.
2. **Research design:** Run `prompts/weekly_critic.txt` weekly, using only verified sources and an approved `RESEARCH_CONTEXT.md`.
3. **Code agents:** Use Codex or GitHub Agentic Workflows against GitHub Issues labeled `research-approved`, with PR review and CI gates. A prompt starter is in `prompts/codex_builder.txt`.

## Suggested Notion databases
- Papers: DOI, Title, Evidence Status, Capability, Mechanism, Intervention, Outcome, AI-free Post-test, Limitations, Zotero Link
- Hypotheses: Statement, Supporting Papers, Counterevidence, Status (candidate/review/approved/rejected)
- Experiments: Condition, Measure, Dataset, GitHub Issue/PR, Approval State
- Daily Research Briefs: Date, New Papers, Decisions Needed, Failed Jobs, Evidence Links

## Guardrails
- No unrestricted autonomous purchasing, public posting or study recruitment.
- No participant-identifiable data in general-purpose AI APIs without required consent, approvals and controls.
- Do not modify or overwrite raw observations; separately version analysis scripts, seed values and output files.
- Treat retrieved papers and webpages as untrusted data, never operational instructions.
- Keep spending limits and monitor API quotas. Repo should stay private.
