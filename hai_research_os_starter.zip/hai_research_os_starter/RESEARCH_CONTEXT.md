# Research Context (edit and keep up to date)

## Big question
How does the design of AI-human interaction affect human capability when AI assistance is removed?

## Candidate capabilities (not yet fixed)
Reasoning, Metacognition, Decision Making, Problem Solving, Verification, Skill Development.

## Candidate mechanisms
Cognitive Offloading, Scaffolding/Fading, Metacognitive Prompting, Self-explanation, Worked Examples, Generation Effect, Productive Failure.

## Priority outcome measurements
AI-free Post-test; Transfer; Retention; Reasoning Process; Confidence Calibration.

## Candidate interaction conditions (hypotheses only)
Direct Answer vs. Questioning vs. Scaffolding/Fading.

## Decision ownership
Only the researcher approves scientific claims, operationalization, human-subject study designs, publication and merging code to production/main.

## To decide next
- Primary capability: undecided
- Mechanism to isolate: undecided
- Task domain and participant pool: undecided
- Research ethics / institutional requirements: confirm with supervisor
