#!/usr/bin/env python3
"""Collect and deduplicate paper metadata from OpenAlex. No LLM claims are generated."""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "research.json"
SEEN = ROOT / "data" / "seen.json"
REPORTS = ROOT / "reports"


def load_json(path: Path, default):
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def fetch_works(query: str, cfg: dict) -> list[dict]:
    params = {
        "search": query,
        "filter": f"from_publication_date:{cfg['from_publication_date']}",
        "per_page": min(int(cfg.get("max_results_per_query", 20)), 100),
        "select": "id,doi,title,publication_date,cited_by_count,primary_location",
    }
    key = os.environ.get("OPENALEX_API_KEY", "").strip()
    if key:
        params["api_key"] = key
    url = "https://api.openalex.org/works?" + urlencode(params)
    req = Request(url, headers={"Accept": "application/json", "User-Agent": "HAI-Research-OS/0.1 (academic discovery)"})
    for attempt in range(3):
        try:
            with urlopen(req, timeout=25) as response:
                payload = json.load(response)
            return payload.get("results", [])
        except (HTTPError, URLError, TimeoutError) as exc:
            if attempt == 2 or isinstance(exc, HTTPError) and exc.code in (400, 401, 403):
                raise RuntimeError(f"OpenAlex request failed for {query!r}: {exc}") from exc
            time.sleep(2 ** attempt)
    return []


def unique_key(paper: dict) -> str:
    return (paper.get("doi") or paper.get("id") or "").strip().lower()


def escape_md(value) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ").strip()


def to_report(date: str, cfg: dict, newly_found: list[dict], fetched: int, errors: list[str]) -> str:
    lines = [
        f"# Literature Scout — {date}", "",
        f"Research focus: {cfg['research_focus']}", "",
        f"- Search hits (before dedup): {fetched}",
        f"- Newly discovered metadata records: {len(newly_found)}",
        f"- Failed queries: {len(errors)}", "",
        "> **Evidence status:** These are search results from OpenAlex metadata only. No PDF/full-text verification, methodological evaluation, or novelty claim has been performed.", "",
        "## Review candidates", "",
    ]
    if newly_found:
        lines += ["| Title | Publication date | DOI / OpenAlex | Matches |", "| --- | --- | --- | --- |"]
        for p in newly_found:
            link = p.get("doi") or p.get("id") or ""
            label = "DOI" if p.get("doi") else "OpenAlex"
            lines.append(f"| {escape_md(p.get('title'))} | {escape_md(p.get('publication_date'))} | [{label}]({link}) | {escape_md(', '.join(sorted(p['_topics'])))} |")
    else:
        lines.append("No unseen papers entered the top search results today. This does not mean that no relevant papers were published.")
    lines += ["", "## Human review checklist", "", "- [ ] Open the original abstract and verify the bibliographic details", "- [ ] Obtain and read the original full text for shortlisted studies", "- [ ] Extract design, participants, interventions, measurement, and limitations", "- [ ] Check claims against the paper, not only an AI summary", "- [ ] Mark as relevant / uncertain / exclude in Zotero or Notion", ""]
    if errors:
        lines += ["## Fetch errors", ""] + [f"- {escape_md(x)}" for x in errors] + [""]
    return "\n".join(lines)


def main() -> None:
    cfg = load_json(CONFIG, {})
    seen = set(load_json(SEEN, []))
    before = len(seen)
    candidates = {}
    errors = []
    fetched = 0
    for q in cfg["queries"]:
        try:
            papers = fetch_works(q, cfg)
            fetched += len(papers)
            for p in papers:
                key = unique_key(p)
                if not key or key in seen:
                    continue
                if key not in candidates:
                    candidates[key] = {**p, "_topics": set()}
                candidates[key]["_topics"].add(q)
        except RuntimeError as exc:
            errors.append(str(exc))
    if errors and len(errors) == len(cfg["queries"]):
        raise RuntimeError("All searches failed. Seen IDs were not modified. " + "; ".join(errors))
    new = sorted(candidates.values(), key=lambda p: (-len(p["_topics"]), p.get("publication_date") or ""), reverse=False)
    new = sorted(new, key=lambda p: (len(p["_topics"]), p.get("publication_date") or ""), reverse=True)
    seen.update(candidates.keys())
    SEEN.parent.mkdir(parents=True, exist_ok=True)
    SEEN.write_text(json.dumps(sorted(seen), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    REPORTS.mkdir(parents=True, exist_ok=True)
    date = dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).strftime("%Y-%m-%d")
    output = REPORTS / f"{date}.md"
    output.write_text(to_report(date, cfg, new, fetched, errors), encoding="utf-8")
    print(f"Created {output}: {len(new)} unseen papers, {fetched} hits, seen {before}→{len(seen)}, {len(errors)} errors")


if __name__ == "__main__":
    main()
