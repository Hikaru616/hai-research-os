import importlib.util
import unittest
from pathlib import Path

p = Path(__file__).resolve().parents[1] / 'scripts' / 'daily_scout.py'
spec = importlib.util.spec_from_file_location('daily_scout', p)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class TestScout(unittest.TestCase):
    def test_doi_key(self):
        self.assertEqual(module.unique_key({'doi': 'https://doi.org/10.1234/ABC'}), 'https://doi.org/10.1234/abc')
    def test_fallback_key(self):
        self.assertEqual(module.unique_key({'id': 'https://openalex.org/W123'}), 'https://openalex.org/w123')
    def test_markdown_escape(self):
        self.assertEqual(module.escape_md('a|b\nc'), 'a\\|b c')
    def test_report_includes_provenance_warning(self):
        report = module.to_report('2026-10-21', {'research_focus': 'test'}, [], 0, [])
        self.assertIn('metadata only', report)

if __name__ == '__main__':
    unittest.main()
